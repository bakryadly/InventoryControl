package application.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import application.Main;
import application.model.ViewList;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import application.model.*;
import javafx.scene.control.Alert;

public class CreateController {

    @FXML
    Button home;

    @FXML
    TextField idText;

    @FXML
    TextField nameText;

    public void initialize() {

    }

    public void firstScreen(ActionEvent event) {

        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("../view/Main.fxml"));
            Main.stage.setScene(new Scene(root, 800, 800));
            Main.stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addItem() {

        if (nameText.getText().isEmpty() || idText.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("You Must Enter Id/Name");
            alert.showAndWait();
        } else {
            String newName = nameText.getText();
            String newId = idText.getText();
            int id = Integer.parseInt(newId);
            if (!findID(id)) {
                try {
                    Files.write(Paths.get("data/groceries.csv"), (newId + "," + newName + "\n").getBytes(), StandardOpenOption.APPEND);
                } catch (IOException e) {
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Information Dialog");
                alert.setHeaderText(null);
                alert.setContentText("This ID is Already Found");
                alert.showAndWait();
            }
        }
    }

    boolean findID(int id) {
        ViewList v = new ViewList();
        ArrayList<Item> items = v.getInventory();
        for (Item item : items) {
            if (item.getId() == id) {
                return true;
            }
        }
        return false;
    }
}
